<div class="hidden sm:block">
    <div class="py-8">
        <div></div>
    </div>
</div>
